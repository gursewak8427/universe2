export const LOADER_START = "LOADER_START";
export const LOADER_STOP = "LOADER_STOP";
export const SUCCESS_MESSAGE = "success msg";
export const ERROR_MESSAGE = "error msg";
export const SET_SUBJECTS = "SET_SUBJECTS";
export const SET_TOTAL_TEST = "SET_TOTAL_TEST";
export const SET_WALLET = "SET_WALLET";
export const SET_CLASSES = "SET_CLASSES";
export const SET_TOPICS = "SET_TOPICS";
export const SET_CHAPTERS = "SET_CHAPTERS";
export const SET_GLOBAL_IMAGE = "set global image view";

